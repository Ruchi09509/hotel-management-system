<?php
session_start();
include("db.php");

// Check user login
if (!isset($_SESSION['user'])) {
    echo "<script>alert('Please login first!'); window.location='user_login.php';</script>";
    exit;
}

$email = $_SESSION['user'];
$userRes = $conn->query("SELECT * FROM users WHERE email='$email'");
$user = $userRes->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Room Booking</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<?php include("header.php"); ?>

<div class="container mx-auto py-10">
  <h2 class="text-3xl font-bold text-center text-blue-600 mb-6">Book a Room</h2>

  <div class="bg-white shadow-lg rounded-xl p-8 w-full max-w-2xl mx-auto">
    <form method="POST" action="booking_process.php" class="space-y-6">
      
      <!-- Room Type -->
      <div>
        <label class="block text-gray-700 font-medium mb-2">Room Type</label>
        <select name="room_type" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
          <option value="">-- Select Room Type --</option>
          <option value="Single Room">Single Room</option>
          <option value="Double Room">Double Room</option>
          <option value="Deluxe Room">Deluxe Room</option>
          <option value="Suite">Suite</option>
        </select>
      </div>

      <!-- Guests -->
      <div>
        <label class="block text-gray-700 font-medium mb-2">No. of Guests</label>
        <input type="number" name="guests" min="1" max="10" required
               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
      </div>

      <!-- Check-in & Check-out -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-gray-700 font-medium mb-2">Check-In Date</label>
          <input type="date" name="check_in" required
                 class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
        </div>
        <div>
          <label class="block text-gray-700 font-medium mb-2">Check-Out Date</label>
          <input type="date" name="check_out" required
                 class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
        </div>
      </div>

      <!-- Phone Number -->
      <div>
        <label class="block text-gray-700 font-medium mb-2">Phone Number</label>
        <input type="text" name="phone" placeholder="Enter contact number" required
               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
      </div>

      <!-- Special Request -->
      <div>
        <label class="block text-gray-700 font-medium mb-2">Special Request</label>
        <textarea name="special_request" rows="3" placeholder="Any additional request?"
                  class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
      </div>

      <!-- Submit Button -->
      <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition">
        Confirm Booking
      </button>
    </form>
  </div>
</div>

<?php include("footer.php"); ?>
</body>
</html>
