<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    // User Registration
    if ($action == "user_register") {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $check = $conn->query("SELECT * FROM users WHERE email='$email'");
        if ($check->num_rows > 0) {
            echo "<script>alert('Email already exists!'); window.location='register.php';</script>";
            exit;
        }

        $conn->query("INSERT INTO users (name,email,password) VALUES ('$name','$email','$password')");
        $_SESSION['user'] = $email;
        echo "<script>alert('Registration Successful!'); window.location='rooms.php';</script>";
    }
}
?>
