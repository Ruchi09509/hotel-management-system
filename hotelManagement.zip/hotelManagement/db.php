<?php
$servername = "localhost";
$username = "root"; 
$password = "";
$dbname = "hotel";

$conn = mysqli_connect($servername, $username, $password, $dbname); 
if(mysqli_connect_errno()) {
    die("database not connected". mysqli_connect_error());
}

?>