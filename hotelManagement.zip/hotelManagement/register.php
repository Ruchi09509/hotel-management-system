<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Registration</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<?php include("header.php"); ?>

<div class="flex items-center justify-center min-h-screen">
  <div class="bg-white shadow-lg rounded-xl p-8 w-full max-w-md">
    <h2 class="text-2xl font-bold text-center text-blue-600 mb-6">User Registration</h2>
    <form method="POST" action="auth_register.php" class="space-y-4">
      <input type="hidden" name="action" value="user_register">
      <input type="text" name="name" placeholder="Full Name" required class="w-full px-4 py-2 border rounded-lg">
      <input type="email" name="email" placeholder="Email" required class="w-full px-4 py-2 border rounded-lg">
      <input type="password" name="password" placeholder="Password" required class="w-full px-4 py-2 border rounded-lg">
      <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg">Register</button>
    </form>
  </div>
</div>

<?php include("footer.php"); ?>
</body>
</html>
