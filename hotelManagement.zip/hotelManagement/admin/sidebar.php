<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
</head>
<body>
   <aside class="w-64 bg-white shadow-lg h-screen p-5">
    <nav class="space-y-4">
        <a href="admin_dashboard.php?page=dashboard" class="block text-gray-700 hover:text-blue-600"><i class="ph ph-gauge"></i> Dashboard</a>
        <a href="admin_dashboard.php?page=show_users" class="block text-gray-700 hover:text-blue-600"><i class="ph ph-users"></i> Show Users</a>
        <a href="admin_dashboard.php?page=show_bookings" class="block text-gray-700 hover:text-blue-600"><i class="ph ph-calendar"></i> Bookings</a>
        <a href="admin_dashboard.php?page=show_services" class="block text-gray-700 hover:text-blue-600"><i class="ph ph-gear"></i> Services</a>
        <a href="admin_dashboard.php?page=show_payments" class="block text-gray-700 hover:text-blue-600"><i class="ph ph-credit-card"></i> Payments</a>
    </nav>
</aside>

    
</body>
</html>

