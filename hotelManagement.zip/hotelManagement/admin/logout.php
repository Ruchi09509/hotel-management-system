<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Sabhi session variables destroy karo
session_unset();
session_destroy();

// Redirect user to login page
header("Location: admin_login.php");
exit;
?>
