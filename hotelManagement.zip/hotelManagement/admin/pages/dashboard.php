<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}
include("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="bg-gray-100">
     <?php

$user_count = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$booking_count = $conn->query("SELECT COUNT(*) as total FROM bookings")->fetch_assoc()['total'];
$service_count = $conn->query("SELECT COUNT(*) as total FROM services")->fetch_assoc()['total'];
$payment_count = $conn->query("SELECT COUNT(*) as total FROM payments")->fetch_assoc()['total'];
$totalBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings")->fetch_assoc()['total'];
$confirmedBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE status='Confirmed'")->fetch_assoc()['total'];
$pendingBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE status='Pending'")->fetch_assoc()['total'];
$cancelledBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE status='Cancelled'")->fetch_assoc()['total'];
?>

<h2 class="text-2xl font-bold mb-6">Dashboard Overview</h2>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <!-- Users Card -->
    <div class="bg-gray-500 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-lg font-semibold">Total Users</h3>
        <p class="text-3xl font-bold mt-2"><?= $user_count ?></p>
        <!--<a href="admin_dashboard.php?page=show_users" class="mt-4 inline-block underline">View Users</a>-->
    </div>

    <!-- Bookings Card -->
    <div class="bg-green-400 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-lg font-semibold">Total Bookings</h3>
        <p class="text-3xl font-bold mt-2"><?= $booking_count ?></p>
       <!-- <a href="admin_dashboard.php?page=show_bookings" class="mt-4 inline-block underline">View Bookings</a>-->
    </div>

    <!-- Services Card -->
    <div class="bg-sky-500 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-lg font-semibold">Total Services</h3>
        <p class="text-3xl font-bold mt-2"><?= $service_count ?></p>
       <!-- <a href="admin_dashboard.php?page=show_services" class="mt-4 inline-block underline">View Services</a>-->
    </div>

    <!-- Payments Card -->
    <div class="bg-red-400 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-lg font-semibold">Total Payments</h3>
        <p class="text-3xl font-bold mt-2"><?= $payment_count ?></p>
      <!--  <a href="admin_dashboard.php?page=show_payments" class="mt-4 inline-block underline">View Payments</a>-->
    </div>


    <!-- conform booking card -->
     <div class="bg-pink-400 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-xl font-semibold">Confirmed Booking</h3>
        <p class="text-2xl"><?= $confirmedBookings?></p>    
    </div>

    <!-- pending booking card -->
     <div class="bg-yellow-400 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-xl font-semibold">Pending Booking</h3>
        <p class="text-2xl"><?= $pendingBookings?></p>    
    </div>

    <!-- cancel booking card -->
     <div class="bg-violet-400 text-white p-6 rounded-lg shadow-lg">
        <h3 class="text-xl font-semibold">Cancelled Booking</h3>
        <p class="text-2xl"><?= $cancelledBookings?></p>    
    </div>  
</div>



<div class="mt-8">
    <p class="text-gray-700">Welcome to the Admin Dashboard. Use the sidebar to manage users, bookings, services, and payments.</p>
</div>

       
      
    
      

</body>
</html>
<?php

?>


