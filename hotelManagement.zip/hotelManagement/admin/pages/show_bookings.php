<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
/*session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}*/
include("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body>
    <?php
$bookings = $conn->query("
    SELECT b.*, u.name AS user_name, s.service_name 
    FROM bookings b 
    JOIN users u ON b.user_id = u.user_id 
    JOIN services s ON b.service_id = s.service_id 
    ORDER BY b.booking_id DESC
");
?>



<h2 class="text-2xl font-bold mb-4">All Bookings</h2>

<table class="w-full border-collapse border">
    <tr class="bg-gray-200">
        <th class="border p-2">ID</th>
        <th class="border p-2">User</th>
        <th class="border p-2">Service</th>
        <th class="border p-2">Guests</th>
        <th class="border p-2">Check-in</th>
        <th class="border p-2">Check-out</th>
        <th class="border p-2">Status</th>
        <th class="border p-2">Action</th>
    </tr>
    <?php if ($bookings->num_rows > 0): ?>
        <?php while($row = $bookings->fetch_assoc()): ?>
            <tr>
    <td class="border p-2"><?= $row['booking_id'] ?></td>
    <td class="border p-2"><?= $row['user_name'] ?></td>
    <td class="border p-2"><?= $row['service_name'] ?></td>
    <td class="border p-2"><?= $row['guests'] ?></td>
    <td class="border p-2"><?= $row['check_in'] ?></td>
    <td class="border p-2"><?= $row['check_out'] ?></td>
    <td class="border p-2"><?= $row['status'] ?></td>
    <td class="border p-2">
        <a href="admin_dashboard.php?page=update_booking&id=<?= $row['booking_id'] ?>&status=Confirmed" 
   class="text-green-600 hover:underline">Confirm</a> |

<a href="admin_dashboard.php?page=update_booking&id=<?= $row['booking_id'] ?>&status=Pending" 
   class="text-yellow-600 hover:underline">Pending</a> |

<a href="admin_dashboard.php?page=update_booking&id=<?= $row['booking_id'] ?>&status=Cancelled" 
   class="text-red-600 hover:underline">Cancel</a>

    </td>
</tr>

        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="8" class="text-center p-4">No Bookings Found</td>
        </tr>
    <?php endif; ?>
</table>


</body>
</html>