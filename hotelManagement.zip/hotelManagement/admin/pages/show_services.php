<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
//session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit;
}

include("../db.php");

// --------------------------------------------------
// 1. Handle Add Service
// --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action']=="add") {
    $service_name = mysqli_real_escape_string($conn, $_POST['service_name']);
    $category     = mysqli_real_escape_string($conn, $_POST['category']);
    $price        = mysqli_real_escape_string($conn, $_POST['price']);

    $sql = "INSERT INTO services (service_name, category, price) 
            VALUES ('$service_name', '$category', '$price')";
    if ($conn->query($sql)) {
        echo "<script>alert('✅ Service Added Successfully'); window.location='admin_dashboard.php?page=show_services';</script>";
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}


// --------------------------------------------------
// 2. Handle Update Service
// --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action']=="update") {
    $id           = intval($_POST['update_id']);
    $service_name = mysqli_real_escape_string($conn, $_POST['service_name']);
    $category     = mysqli_real_escape_string($conn, $_POST['category']);
    $price        = mysqli_real_escape_string($conn, $_POST['price']);

    $sql = "UPDATE services 
            SET service_name='$service_name', category='$category', price='$price'
            WHERE service_id=$id";
    if ($conn->query($sql)) {
        echo "<script>alert('✅ Service Updated Successfully'); window.location='admin_dashboard.php?page=show_services';</script>";
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

// --------------------------------------------------
// 3. Fetch record for edit (if ?edit=id)
// --------------------------------------------------
$editData = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $res = $conn->query("SELECT * FROM services WHERE service_id=$id LIMIT 1");
    if ($res->num_rows > 0) {
        $editData = $res->fetch_assoc();
    } else {
        echo "<script>alert('❌ Service not found'); window.location='admin_dashboard.php?page=show_services';</script>";
        exit;
    }
}

// --------------------------------------------------
// 4. Delete Service (if ?delete=id)
// --------------------------------------------------
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM services WHERE service_id=$id");
    echo "<script>alert('🗑️ Service Deleted'); window.location='admin_dashboard.php?page=show_services';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Services Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">

  <!-- Add / Update Service Form -->
  <div class="bg-white p-6 rounded-lg shadow-lg mb-8">
    <h2 class="text-2xl font-bold mb-4">
      <?php echo $editData ? "✏️ Update Service" : "➕ Add Service"; ?>
    </h2>

    <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <?php if($editData): ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="update_id" value="<?php echo $editData['service_id']; ?>">
      <?php else: ?>
        <input type="hidden" name="action" value="add">
      <?php endif; ?>

      <!-- Service Name -->
      <div>
        <label class="block mb-2 font-semibold">Service</label>
        <select name="service_name" id="service_name" class="w-full p-2 border rounded" required>
          <option value="">-- Select Service --</option>
          <?php
          $servicesList = ["rooms","spa","gym","sports","food","banquet"];
          foreach($servicesList as $srv){
              $sel = ($editData && $editData['service_name']==$srv) ? "selected" : "";
              echo "<option value='$srv' $sel>".ucfirst($srv)."</option>";
          }
          ?>
        </select>
      </div>

      <!-- Category -->
      <div>
        <label class="block mb-2 font-semibold">Category</label>
        <input type="text" name="category" class="w-full p-2 border rounded" 
               value="<?php echo $editData ? htmlspecialchars($editData['category']) : ''; ?>" required>
      </div>

      <!-- Price -->
      <div>
        <label class="block mb-2 font-semibold">Price</label>
        <input type="number" step="0.01" name="price" class="w-full p-2 border rounded" 
               value="<?php echo $editData ? htmlspecialchars($editData['price']) : ''; ?>" required>
      </div>

      <div class="col-span-1 md:col-span-3">
        <button type="submit" class="<?php echo $editData ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'; ?> text-white px-6 py-2 rounded-lg">
          <?php echo $editData ? "Update Service" : "Add Service"; ?>
        </button>
        <?php if($editData): ?>
          <a href="admin_dashboard.php?page=show_services" class="ml-4 bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600">Cancel</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Services Table -->
  <div class="bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-4">📋 Services List</h2>
    <table class="w-full border-collapse border">
      <tr class="bg-gray-200">
        <th class="border p-2">ID</th>
        <th class="border p-2">Service</th>
        <th class="border p-2">Category</th>
        <th class="border p-2">Price</th>
        <th class="border p-2">Action</th>
      </tr>
      <?php
      $services = $conn->query("SELECT * FROM services ORDER BY service_id DESC");
      if ($services->num_rows > 0) {
          while ($row = $services->fetch_assoc()) {
              echo "<tr>
                      <td class='border p-2'>{$row['service_id']}</td>
                      <td class='border p-2'>{$row['service_name']}</td>
                      <td class='border p-2'>{$row['category']}</td>
                      <td class='border p-2'>{$row['price']}</td>
                      <td class='border p-2'>
                        <a href='admin_dashboard.php?page=show_services&edit={$row['service_id']}' class='text-blue-600 hover:underline'>Edit</a> | 
                        <a href='admin_dashboard.php?page=show_services&delete={$row['service_id']}' class='text-red-600 hover:underline' onclick=\"return confirm('Are you sure?')\">Delete</a>
                      </td>
                    </tr>";
          }
      } else {
          echo "<tr><td colspan='5' class='text-center p-4'>No Services Found</td></tr>";
      }
      ?>
    </table>
  </div>
  <script>
  // Dynamic Category Dropdown
  const serviceCategories = {
    rooms: ["Suite", "Deluxe", "Family", "Normal"],
    spa: ["Full Body Massage", "Pedicure", "Manicure", "Hair Wash"],
    gym: ["Gym"],
    sports: ["Pool", "Archery", "Tennis", "Swimming"],
    food: ["Indian", "Italian", "Continental", "Chinese", "Thai"],
    banquet: ["Conference", "Marriage", "Party", "Meetups"]
  };

  const serviceSelect = document.getElementById("service_name");
  const categorySelect = document.getElementById("category");

  function loadCategories(service) {
    categorySelect.innerHTML = '<option value="">-- Select Category --</option>';
    if (serviceCategories[service]) {
      serviceCategories[service].forEach(cat => {
        const option = document.createElement("option");
        option.value = cat;
        option.textContent = cat;
        categorySelect.appendChild(option);
      });
    }
  }

  // On service change
  serviceSelect.addEventListener("change", function () {
    loadCategories(this.value);
  });

  // Load categories if service pre-selected
  if (serviceSelect.value) {
    loadCategories(serviceSelect.value);
  }
  </script>


</body>
</html>
