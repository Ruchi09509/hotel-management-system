<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
//session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit;
}

include("../db.php");

// --------------------------------------------------
// Handle Block / Unblock Action
// --------------------------------------------------
if (isset($_GET['block_id'])) {
    $id = intval($_GET['block_id']);
    $conn->query("UPDATE users SET block=1 WHERE user_id=$id");
    echo "<script>alert('🚫 User Blocked'); window.location='admin_dashboard.php?page=show_users';</script>";
    exit;
}

if (isset($_GET['unblock_id'])) {
    $id = intval($_GET['unblock_id']);
    $conn->query("UPDATE users SET block=0 WHERE user_id=$id");
    echo "<script>alert('✅ User Unblocked'); window.location='admin_dashboard.php?page=show_users';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Users Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">

  <div class="bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-4">👥 Registered Users</h2>

    <table class="w-full border-collapse border">
      <tr class="bg-gray-200">
        <th class="border p-2">User ID</th>
        <th class="border p-2">Name</th>
        <th class="border p-2">Email</th>
        <th class="border p-2">Status</th>
        <th class="border p-2">Action</th>
      </tr>
      <?php
      $users = $conn->query("SELECT * FROM users ORDER BY user_id DESC");
      if ($users->num_rows > 0) {
          while ($row = $users->fetch_assoc()) {
              $status = $row['block'] == 1 ? "❌ Blocked" : "✅ Active";
              echo "<tr>
                      <td class='border p-2'>{$row['user_id']}</td>
                      <td class='border p-2'>{$row['name']}</td>
                      <td class='border p-2'>{$row['email']}</td>
                      <td class='border p-2'>$status</td>
                      <td class='border p-2'>";
              
              if ($row['block'] == 1) {
                  echo "<a href='admin_dashboard.php?page=show_users&unblock_id={$row['user_id']}' class='bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700'>Unblock</a>";
              } else {
                  echo "<a href='admin_dashboard.php?page=show_users&block_id={$row['user_id']}' class='bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700'>Block</a>";
              }

              echo "</td></tr>";
          }
      } else {
          echo "<tr><td colspan='5' class='text-center p-4'>No Users Found</td></tr>";
      }
      ?>
    </table>
  </div>

</body>
</html>
