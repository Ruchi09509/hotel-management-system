<?php
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit;
}

if (isset($_GET['id']) && isset($_GET['status'])) {
    $booking_id = intval($_GET['id']);
    $status = $_GET['status'];

    $allowed_status = ['Confirmed', 'Pending', 'Cancelled'];
    if (!in_array($status, $allowed_status)) {
        echo "<p class='text-red-600'>❌ Invalid status</p>";
        exit;
    }

    $sql = "UPDATE bookings SET status='$status' WHERE booking_id=$booking_id";
    if ($conn->query($sql)) {
        echo "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4'>
                ✅ Booking #$booking_id updated to <strong>$status</strong>.
              </div>";
        echo "<a href='admin_dashboard.php?page=show_bookings' class='bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'>
                ⬅ Back to Bookings
              </a>";
    } else {
        echo "<p class='text-red-600'>❌ Error: " . $conn->error . "</p>";
    }
} else {
    echo "<p class='text-red-600'>❌ Invalid Request</p>";
}
?>
