<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="bg-gray-100">

  <!-- Header -->
  <?php include("header.php"); ?>

  <div class="flex">
    <!-- Sidebar -->
    <?php include("sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-8">
      <div class="bg-white p-6 rounded-lg shadow">
        <?php
        $page = $_GET['page'] ?? 'dashboard';
        $allowed_pages = ['dashboard','show_users','show_bookings','show_services','show_payments','update_booking','add_services'];

        if (in_array($page, $allowed_pages)) {
            include __DIR__ . "/pages/$page.php";
        } else {
            echo "<h2 class='text-2xl font-bold'>404 - Page Not Found</h2>";
        }
        ?>
      </div>
    </main>
  </div>

</body>
</html>
