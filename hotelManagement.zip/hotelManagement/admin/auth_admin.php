<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

     // Admin Login
    if ($action == "admin_login") {
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Example admin (you can also make separate admin table)
        if ($email == "admin@hotel.com" && $password == "admin123") {
            $_SESSION['admin'] = $email;
            echo "<script>alert('Admin Login Successful!'); window.location='admin_dashboard.php';</script>";
        } else {
            echo "<script>alert('Invalid Admin Credentials!'); window.location='admin_login.php';</script>";
        }
    }

}