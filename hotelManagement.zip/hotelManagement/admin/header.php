<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
</head>
<body>
    <header class="bg-blue-700 text-white shadow-lg px-6 py-4 flex justify-between items-center">
    <h1 class="text-2xl font-bold">Admin Dashboard</h1>
    <a href="logout.php" class="bg-red-500 px-4 py-2 rounded-lg hover:bg-red-600">Logout</a>
</header>
    
</body>
</html>

