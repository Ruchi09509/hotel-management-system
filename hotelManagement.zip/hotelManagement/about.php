<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <?php include("header.php"); ?>

<section class="max-w-7xl mx-auto px-6 py-16">
  <h1 class="text-4xl font-bold text-center mb-10">About Us</h1>
  <div class="grid md:grid-cols-2 gap-10 items-center">
    <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945" class="rounded-2xl shadow-lg">
    <div>
      <h2 class="text-2xl font-semibold mb-4">Welcome to MyHotel</h2>
      <p class="text-gray-600 mb-4">
        At MyHotel, we believe in offering more than just a stay. We create unforgettable experiences 
        with world-class amenities, luxury rooms, and exceptional service.
      </p>
      <p class="text-gray-600 mb-4">
        Our hotel is located in the heart of the city, making it a perfect destination for both 
        business and leisure travelers.
      </p>
      <ul class="list-disc pl-5 text-gray-700">
        <li>Luxury Rooms & Suites</li>
        <li>24/7 Room Service</li>
        <li>Swimming Pool & Spa</li>
        <li>Fine Dining Restaurant</li>
      </ul>
    </div>
  </div>
</section>

<?php include("footer.php"); ?>

</body>
</html>