<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <!-- footer.php -->
<footer class="bg-gray-900 text-white mt-10">
  <div class="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-8">
    
    <!-- About -->
    <div>
      <h3 class="text-xl font-bold mb-3">MyHotel</h3>
      <p class="text-gray-400">Luxury and comfort at your fingertips. Book your perfect stay with us today.</p>
    </div>

    <!-- Links -->
    <div>
      <h3 class="text-xl font-bold mb-3">Quick Links</h3>
      <ul class="space-y-2 text-gray-400">
        <li><a href="index.php" class="hover:text-blue-400">Home</a></li>
        <li><a href="#rooms" class="hover:text-blue-400">Rooms</a></li>
        <li><a href="#about" class="hover:text-blue-400">About</a></li>
        <li><a href="#contact" class="hover:text-blue-400">Contact</a></li>
      </ul>
    </div>

    <!-- Contact -->
    <div>
      <h3 class="text-xl font-bold mb-3">Contact Us</h3>
      <p class="text-gray-400 flex items-center gap-2"><i class="fas fa-map-marker-alt"></i> New Delhi, India</p>
      <p class="text-gray-400 flex items-center gap-2"><i class="fas fa-phone"></i> +91 98765 43210</p>
      <p class="text-gray-400 flex items-center gap-2"><i class="fas fa-envelope"></i> support@myhotel.com</p>
    </div>
  </div>

  <div class="text-center py-4 bg-gray-800 text-gray-400">
    © 2025 MyHotel. All Rights Reserved.
  </div>
</footer>

</body>
</html>