<?php
session_start();
include("db.php");

if (!isset($_SESSION['user'])) {
    echo "<script>alert('Please login first!'); window.location='user_login.php';</script>";
    exit;
}

$email = $_SESSION['user'];
$userRes = $conn->query("SELECT * FROM users WHERE email='$email'");
$user = $userRes->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $room_type = $_POST['room_type'];
    $guests = $_POST['guests'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $phone = $_POST['phone'];
    $special_request = $_POST['special_request'];

    $sql = "INSERT INTO bookings (user_id, room_type, guests, check_in, check_out, phone, special_request) 
            VALUES ('{$user['id']}', '$room_type', '$guests', '$check_in', '$check_out', '$phone', '$special_request')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Room booked successfully!'); window.location='user/dashboard.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
