<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
  <?php include("header.php"); ?>

<section class="max-w-7xl mx-auto px-6 py-16">
  <h1 class="text-4xl font-bold text-center mb-10">Our Rooms</h1>
  
  <div class="grid md:grid-cols-3 gap-8">
    <!-- Deluxe Room -->
    <div class="bg-white shadow-md rounded-2xl overflow-hidden">
      <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c" class="w-full h-56 object-cover">
      <div class="p-5">
        <h3 class="text-xl font-semibold">Deluxe Room</h3>
        <p class="text-gray-500 mt-2">Luxury at an affordable price.</p>
        <p class="text-blue-600 font-bold mt-3">₹3500 / night</p>
        <a href="user/user_login.php?room=deluxe" class="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full">Book Now</a>
      </div>
    </div>

    <!-- Suite Room -->
    <div class="bg-white shadow-md rounded-2xl overflow-hidden">
      <img src="https://images.unsplash.com/photo-1505691723518-36a5ac3be353" class="w-full h-56 object-cover">
      <div class="p-5">
        <h3 class="text-xl font-semibold">Suite Room</h3>
        <p class="text-gray-500 mt-2">Spacious suite with premium facilities.</p>
        <p class="text-blue-600 font-bold mt-3">₹6000 / night</p>
        <a href="user/user_login.php?room=suite" class="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full">Book Now</a>
      </div>
    </div>

    <!-- Family Room -->
    <div class="bg-white shadow-md rounded-2xl overflow-hidden">
      <img src="images/room2.jpeg" class="w-full h-56 object-cover">
      <div class="p-5">
        <h3 class="text-xl font-semibold">Family Room</h3>
        <p class="text-gray-500 mt-2">Perfect for families with kids.</p>
        <p class="text-blue-600 font-bold mt-3">₹4500 / night</p>
        <a href="user/user_login.php?room=family" class="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full">Book Now</a>
      </div>
    </div>
  </div>
</section>

<?php include("footer.php"); ?>

  
</body>
</html>