<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>

</head>
<body>
 
<?php include("header.php"); ?>

<!-- Hero Section -->
<section class="bg-[url('https://images.unsplash.com/photo-1501117716987-c8e3e1c77e3c')] bg-cover bg-center h-[80vh] flex items-center justify-center">
  <div class="bg-black bg-opacity-50 p-10 rounded-xl text-center text-white">
    <h1 class="text-5xl font-bold mb-4">Welcome to MyHotel</h1>
    <p class="text-lg mb-6">Your perfect destination for luxury and comfort</p>
    
    <!-- Buttons -->
    <div class="flex gap-4 justify-center">
      <a href="rooms.php" class="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-full">Book Now</a>
       <a href="register.php" class="bg-green-600 hover:bg-green-700 px-6 py-3 rounded-full">User Register</a>

    </div>
  </div>
</section>

<?php include("footer.php"); ?>

</body>
</html>