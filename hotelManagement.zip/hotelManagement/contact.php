<?php
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <?php include("header.php"); ?>

<section class="max-w-7xl mx-auto px-6 py-16">
  <h1 class="text-4xl font-bold text-center mb-10">Contact Us</h1>

  <div class="grid md:grid-cols-2 gap-12">
    
    <!-- Contact Info -->
    <div>
      <h2 class="text-2xl font-semibold mb-4">Get in Touch</h2>
      <p class="text-gray-600 mb-6">We’d love to hear from you! Please fill out the form or contact us directly.</p>
      <p class="flex items-center gap-3 text-gray-700 mb-3"><i class="fas fa-map-marker-alt text-blue-600"></i> New Delhi, India</p>
      <p class="flex items-center gap-3 text-gray-700 mb-3"><i class="fas fa-phone text-blue-600"></i> +91 98765 43210</p>
      <p class="flex items-center gap-3 text-gray-700"><i class="fas fa-envelope text-blue-600"></i> support@myhotel.com</p>
    </div>

    <!-- Feedback Form -->
    <form action="contact_process.php" method="POST" class="bg-white shadow-lg p-8 rounded-2xl">
      <h2 class="text-xl font-semibold mb-6">Send Feedback</h2>
      <div class="mb-4">
        <label class="block text-gray-700 mb-2">Name</label>
        <input type="text" name="name" required class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 mb-2">Email</label>
        <input type="email" name="email" required class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 mb-2">Message</label>
        <textarea name="message" rows="4" required class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
      </div>
      <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full">Submit</button>
    </form>
  </div>
</section>

<?php include("footer.php"); ?>

</body>
</html>