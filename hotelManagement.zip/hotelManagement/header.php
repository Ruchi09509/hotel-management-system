<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <header class="bg-gray-800 text-white shadow-md">
  <div class="container mx-auto flex justify-between items-center p-4">
    <h1 class="text-2xl font-bold">MyHotel</h1>
    <nav>
      <ul class="flex space-x-6">
        <li><a href="index.php" class="hover:text-blue-400">Home</a></li>
        <li><a href="about.php" class="hover:text-blue-400">About</a></li>
        <li><a href="rooms.php" class="hover:text-blue-400">Rooms</a></li>
        <li><a href="contact.php" class="hover:text-blue-400">Contact</a></li>

        <!-- Login Dropdown -->
        <li class="relative group">
          <button class="flex items-center hover:text-blue-400">
            <span class="mr-2">Login</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
          </button>
          <ul class="absolute hidden group-hover:block bg-white text-black mt-0 rounded shadow-lg w-40">
            <li><a href="user/user_login.php" onclick="openUserModal()" class="block px-4 py-2 hover:bg-gray-200">User Login</a></li>
            <li><a href="admin/admin_login.php" onclick="openAdminModal()" class="block px-4 py-2 hover:bg-gray-200">Admin Login</a></li>
          </ul>
        </li>
      </ul>
    </nav>
  </div>
</header>


    
</body>
</html>