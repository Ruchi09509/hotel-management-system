<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("db.php"); 

if ($_SERVER['REQUEST_METHOD'] == "POST"){
$name=$_POST["name"];
$email=$_POST["email"];
$message=$_POST["message"];

$sql="INSERT INTO feedback(name,email,message) VALUES ('$name','$email','$message')";
$result=mysqli_query($conn,$sql);
if($result==true){
 echo "<script>alert('Feedback recieved Successful!  thank you for giving this feedback'); window.location='contact.php';</script>";
        } 
}
?>