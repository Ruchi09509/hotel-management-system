<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action']; // User Login
    if ($action == "user_login") {
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Query user
        $res = $conn->query("SELECT * FROM users WHERE email='$email'");
        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();

            // Verify password
            if (password_verify($password, $row['password'])) {
                // ✅ Set correct session variables
                $_SESSION['user_id'] = $row['user_id']; // IMPORTANT
                $_SESSION['name']    = $row['name'];
                $_SESSION['email']   = $row['email'];

                echo "<script>alert('Login Successful!'); window.location='user_dashboard.php';</script>";
                exit;
            } else {
                echo "<script>alert('Invalid Password!'); window.location='user_login.php';</script>";
                exit;
            }
        } else {
            echo "<script>alert('User not found!'); window.location='user_login.php';</script>";
            exit;
        }
    }
}
?>
