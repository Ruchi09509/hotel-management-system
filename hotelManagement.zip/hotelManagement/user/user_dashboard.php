<?php
include("db.php");
session_start();
if (!isset($_SESSION['user_id'])) {
    //echo "<script>alert('Please login first!'); window.location='user_login.php';</script>";
    //exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="bg-gray-100">

  <!-- Header -->
  <header class="bg-blue-600 text-white shadow-lg px-6 py-4 flex justify-between items-center">
    <h1 class="text-2xl font-bold">User Dashboard</h1>
    <div>
      <span class="mr-4">Welcome, <?php echo $_SESSION['username']; ?></span>
      <a href="logout.php" class="bg-red-500 px-4 py-2 rounded-lg hover:bg-red-600">Logout</a>
    </div>
  </header>

  <!-- Layout -->
  <div class="flex">
    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-lg h-screen p-5">
      <nav class="space-y-4">
        <a href="?page=dashboard" class="flex items-center gap-2 text-gray-700 hover:text-blue-600">
          <i class="ph ph-gauge"></i> Dashboard
        </a>
        <a href="?page=user_bookings" class="flex items-center gap-2 text-gray-700 hover:text-blue-600">
          <i class="ph ph-calendar-check"></i> My Bookings
        </a>
        <a href="?page=user_payment" class="flex items-center gap-2 text-gray-700 hover:text-blue-600">
          <i class="ph ph-credit-card"></i> Payments
        </a>
        <a href="?page=user_status_active" class="flex items-center gap-2 text-gray-700 hover:text-blue-600">
          <i class="ph ph-check-circle"></i> Active
        </a>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-8">
      <div class="bg-white shadow-lg rounded-xl p-6">
        <?php
        $page = $_GET['page'] ?? 'dashboard';
        $allowed_pages = ['dashboard','user_bookings','user_payment','user_status_active','payment_form'];

        if (in_array($page, $allowed_pages)) {
            include __DIR__ . "/pages/$page.php";
        } else {
            echo "<h2 class='text-2xl font-bold'>404 - Page Not Found</h2>";
        }
        ?>
      </div>
    </main>
  </div>

</body>
</html>
