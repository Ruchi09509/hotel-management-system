<?php
session_start();
include("../db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../user_login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$activeBookings = $conn->query("
    SELECT b.*, s.service_name 
    FROM bookings b
    JOIN services s ON b.service_id = s.service_id
    WHERE b.user_id = $user_id AND b.status='Confirmed'
    ORDER BY b.booking_id DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>hotel</title>
</head>
<body>
<h2 class="text-2xl font-bold mb-4">✅ Active Bookings</h2>

<table class="w-full border-collapse border">
  <tr class="bg-gray-200">
    <th class="border p-2">Booking ID</th>
    <th class="border p-2">Service</th>
    <th class="border p-2">Guests</th>
    <th class="border p-2">Check-in</th>
    <th class="border p-2">Check-out</th>
    <th class="border p-2">Status</th>
  </tr>
  <?php if ($activeBookings->num_rows > 0): ?>
    <?php while ($row = $activeBookings->fetch_assoc()): ?>
      <tr>
        <td class="border p-2"><?= $row['booking_id'] ?></td>
        <td class="border p-2"><?= $row['service_name'] ?></td>
        <td class="border p-2"><?= $row['guests'] ?></td>
        <td class="border p-2"><?= $row['check_in'] ?></td>
        <td class="border p-2"><?= $row['check_out'] ?></td>
        <td class="border p-2 text-green-600 font-bold"><?= $row['status'] ?></td>
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr><td colspan="6" class="text-center p-4">No Active Bookings</td></tr>
  <?php endif; ?>
</table>
  

</body>
</html>

