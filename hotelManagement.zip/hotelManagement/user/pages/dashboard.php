<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login first!'); window.location='../user_login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id'];

// Personalized stats
$totalBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE user_id=$user_id")->fetch_assoc()['total'];
$confirmedBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE user_id=$user_id AND status='Confirmed'")->fetch_assoc()['total'];
$pendingBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE user_id=$user_id AND status='Pending'")->fetch_assoc()['total'];
$cancelledBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE user_id=$user_id AND status='Cancelled'")->fetch_assoc()['total'];

// FIXED: Payments linked through bookings
$totalPayments = $conn->query("
    SELECT IFNULL(SUM(p.amount),0) AS total
    FROM payments p
    JOIN bookings b ON p.booking_id = b.booking_id
    WHERE b.user_id = $user_id
")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="bg-gray-100">

<h2 class="text-2xl font-bold mb-6">My Dashboard</h2>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
<div class="bg-green-400 text-white p-6 rounded-lg shadow-lg">
  <h3 class="text-lg font-semibold">Total Bookings</h3>
  <p class="text-3xl font-bold mt-2"><?= $totalBookings ?></p>
</div>

<div class="bg-red-400 text-white p-6 rounded-lg shadow-lg">
  <h3 class="text-lg font-semibold">Total Payments</h3>
  <p class="text-3xl font-bold mt-2">₹<?= $totalPayments ?></p>
</div>

    

</div>

<div class="mt-8">
    <p class="text-gray-700">Welcome back! Here’s an overview of your bookings and payments.</p>
</div>

</body>
</html>
