<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login first!'); window.location='../user_login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch services for dropdown
$services = $conn->query("SELECT * FROM services");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_id = $_POST['service_id'];
    $guests = $_POST['guests'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $phone = $_POST['phone'];
    $special_request = $_POST['special_request'];
    $totalamount = $_POST['totalamount'];

    $sql = "INSERT INTO bookings 
            (user_id, service_id, guests, check_in, check_out, phone, special_request, totalamount, status) 
            VALUES 
            ('$user_id', '$service_id', '$guests', '$check_in', '$check_out', '$phone', '$special_request', '$totalamount', 'Pending')";

    if ($conn->query($sql)) {
        echo "<script>alert('Booking Successful!'); window.location='user_dashboard.php?page=user_bookings';</script>";
        exit;
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Fetch existing bookings
$bookings = $conn->query("SELECT b.*, s.service_name, s.category, s.price 
                          FROM bookings b 
                          JOIN services s ON b.service_id = s.service_id
                          WHERE b.user_id = '$user_id' 
                          ORDER BY b.booking_id DESC");
?>

<!-- Add Booking Button -->
<button onclick="document.getElementById('bookingForm').classList.toggle('hidden')" 
        class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 mb-4">
  + Add Booking
</button>

<!-- Booking Table -->
<div class="overflow-x-auto">
  <table class="w-full border-collapse border">
    <tr class="bg-gray-200">
      <th class="border p-2">Booking ID</th>
      <th class="border p-2">Service</th>
      <th class="border p-2">Category</th>
      <th class="border p-2">Price/Day</th>
      <th class="border p-2">Guests</th>
      <th class="border p-2">Check-in</th>
      <th class="border p-2">Check-out</th>
      <th class="border p-2">Total Pay</th>
      <th class="border p-2">Phone</th>
      <th class="border p-2">Status</th>
    </tr>
    <?php while($row = $bookings->fetch_assoc()) { ?>
      <tr>
        <td class="border p-2"><?= $row['booking_id'] ?></td>
        <td class="border p-2"><?= $row['service_name'] ?></td>
        <td class="border p-2"><?= $row['category'] ?></td>
        <td class="border p-2">₹<?= $row['price']?></td>
        <td class="border p-2"><?= $row['guests'] ?></td>
        <td class="border p-2"><?= $row['check_in'] ?></td>
        <td class="border p-2"><?= $row['check_out'] ?></td>
        <td class="border p-2">₹<?= $row['totalamount']?></td>
        <td class="border p-2"><?= $row['phone'] ?></td>
        <td class="border p-2"><?= $row['status'] ?></td>
      </tr>
    <?php } ?>
  </table>
</div>

<!-- Booking Form (Initially Hidden) -->
<div id="bookingForm" class="hidden mt-6 max-w-lg mx-auto bg-white shadow-lg rounded-lg p-6">
  <h2 class="text-xl font-bold mb-4 text-blue-600">New Booking</h2>
  <form method="POST" id="bookingFormSubmit">
    <!-- Service -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">Select Service</label>
      <select name="service_id" id="serviceSelect" required class="w-full border rounded-lg px-3 py-2">
        <option value="">-- Choose Service --</option>
        <?php while($row = $services->fetch_assoc()) { ?>
          <option value="<?= $row['service_id'] ?>" data-price="<?= $row['price'] ?>">
            <?= $row['service_name'] ?> (<?= $row['category'] ?> - ₹<?= $row['price'] ?>/day)
          </option>
        <?php } ?>
      </select>
    </div>
  
    <!-- Guests -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">No. of Guests</label>
      <input type="number" name="guests" required min="1" class="w-full border rounded-lg px-3 py-2">
    </div>

    <!-- Check-in -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">Check-In Date & Time</label>
      <input type="datetime-local" name="check_in" id="checkin" required class="w-full border rounded-lg px-3 py-2">
    </div>

    <!-- Check-out -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">Check-Out Date & Time</label>
      <input type="datetime-local" name="check_out" id="checkout" required class="w-full border rounded-lg px-3 py-2">
    </div>

    <!-- total payment -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">Total Pay</label>
      <input type="text" id="totalPay" readonly class="w-full border rounded-lg px-3 py-2 bg-gray-100">
      <input type="hidden" name="totalamount" id="totalamountHidden">
    </div>

    <!-- Phone -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">Phone</label>
      <input type="text" name="phone" required class="w-full border rounded-lg px-3 py-2">
    </div>

    <!-- Special Request -->
    <div class="mb-4">
      <label class="block mb-2 font-semibold">Special Request</label>
      <textarea name="special_request" rows="3" class="w-full border rounded-lg px-3 py-2"></textarea>
    </div>

    <div class="text-center">
      <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
        Book Now
      </button>
    </div>
  </form>
</div>

<script>
const serviceSelect = document.getElementById("serviceSelect");
const checkinInput = document.getElementById("checkin");
const checkoutInput = document.getElementById("checkout");
const totalPayField = document.getElementById("totalPay");
const totalPayHidden = document.getElementById("totalamountHidden");

function calculateAmount() {
    const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
    const price = selectedOption.getAttribute("data-price");
    const checkin = new Date(checkinInput.value);
    const checkout = new Date(checkoutInput.value);

    if (price && checkin && checkout && checkout > checkin) {
        const diffTime = Math.abs(checkout - checkin);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const total = diffDays * price;
        totalPayField.value = "₹" + total;
        totalPayHidden.value = total;
    }
}

serviceSelect.addEventListener("change", calculateAmount);
checkinInput.addEventListener("change", calculateAmount);
checkoutInput.addEventListener("change", calculateAmount);
</script>
