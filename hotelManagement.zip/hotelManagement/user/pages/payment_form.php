<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login first!'); window.location='../user_login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id'];
$booking_id = (int) ($_GET['booking_id'] ?? 0);

if ($booking_id <= 0) {
    die("Invalid Booking ID.");
}

// Fetch booking details
$result = $conn->query("
    SELECT b.booking_id, s.service_name, s.category, s.price 
    FROM bookings b
    JOIN services s ON b.service_id = s.service_id
    WHERE b.booking_id = $booking_id AND b.user_id = $user_id AND b.status='Confirmed'
");

if (!$result || $result->num_rows == 0) {
    die("Booking not found or not confirmed.");
}
$booking = $result->fetch_assoc();

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $method = mysqli_real_escape_string($conn, $_POST['method']);
    $amount = $booking['price'];

    $sql = "INSERT INTO payments (booking_id, amount, status) VALUES ($booking_id, $amount, 'confirmed')";
    if ($conn->query($sql)) {
        echo "<script>alert('✅ Payment initiated via $method!'); window.location='user_dashboard.php?page=user_payment';</script>";
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Form</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex justify-center items-center min-h-screen">

<div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-md">
  <h2 class="text-2xl font-bold mb-4">💳 Payment for Booking #<?= $booking['booking_id'] ?></h2>
  <p class="mb-2"><strong>Service:</strong> <?= $booking['service_name'] ?> (<?= $booking['category'] ?>)</p>
  <p class="mb-4"><strong>Amount:</strong> ₹<?= $booking['price'] ?></p>

  <form method="POST">
    <label class="block mb-2 font-semibold">Select Payment Method:</label>
    <select name="method" class="w-full p-2 border rounded mb-4" required>
      <option value="">-- Select Method --</option>
      <option value="Credit Card">Credit Card</option>
      <option value="Debit Card">Debit Card</option>
      <option value="Net Banking">Net Banking</option>
      <option value="UPI">UPI</option>
    </select>

    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 w-full">Proceed to Pay</button>
  </form>
</div>

</body>
</html>
