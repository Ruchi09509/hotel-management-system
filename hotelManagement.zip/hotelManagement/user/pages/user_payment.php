<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login first!'); window.location='../user_login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle payment action
if (isset($_GET['pay']) && is_numeric($_GET['pay'])) {
    $booking_id = (int) $_GET['pay'];

    // Get booking price
    $result = $conn->query("
        SELECT s.price 
        FROM bookings b 
        JOIN services s ON b.service_id = s.service_id
        WHERE b.booking_id = $booking_id AND b.user_id = $user_id AND b.status='Confirmed'
    ");

    if ($result && $result->num_rows > 0) {
        $price = $result->fetch_assoc()['price'];

        // Insert payment with pending status
        $conn->query("INSERT INTO payments (booking_id, amount, status) VALUES ($booking_id, $price, 'Pending')");

        echo "<script>alert('✅ Payment initiated successfully!'); window.location='user_dashboard.php?page=user_payment';</script>";
        exit;
    } else {
        echo "<script>alert('❌ Invalid booking or not confirmed.');</script>";
    }
}

// Fetch confirmed bookings that are unpaid
$bookings = $conn->query("
    SELECT b.booking_id, s.service_name, s.category,b.totalamount, b.status 
    FROM bookings b
    JOIN services s ON b.service_id = s.service_id
    WHERE b.user_id = $user_id AND b.status='Confirmed'
");
?>

<h2 class="text-2xl font-bold mb-4">💳 My Payments</h2>

<table class="w-full border-collapse border">
    <tr class="bg-gray-200">
        <th class="border p-2">Booking ID</th>
        <th class="border p-2">Service</th>
        <th class="border p-2">Category</th>
        <th class="border p-2">Price</th>
        <th class="border p-2">Status</th>
        <th class="border p-2">Action</th>
    </tr>
    <?php if ($bookings->num_rows > 0): ?>
        <?php while($row = $bookings->fetch_assoc()): ?>
            <tr>
                <td class="border p-2"><?= $row['booking_id'] ?></td>
                <td class="border p-2"><?= $row['service_name'] ?></td>
                <td class="border p-2"><?= $row['category'] ?></td>
                <td class="border p-2">₹<?= $row['totalamount'] ?></td>
                <td class="border p-2"><?= $row['status'] ?></td>
                <td class="border p-2">
    <a href="user_dashboard.php?page=payment_form&booking_id=<?= $row['booking_id'] ?>" 
       class="bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600">Pay Now</a>
</td>

            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center p-4">No confirmed bookings available for payment.</td>
        </tr>
    <?php endif; ?>
</table>
